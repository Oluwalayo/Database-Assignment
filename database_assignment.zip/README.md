# Introduction to Databases – Assignment

## 📚 Assignment Questions
1. Write an SQL query to retrieve the `checkNumber`, `paymentDate`, and `amount` from the `payments` table.  
2. Write an SQL query to retrieve the `orderDate`, `requiredDate`, and `status` of orders that are currently `'In Process'` from the `orders` table. Sort the results in descending order of `orderDate`.  
3. Write a query to display the `firstName`, `lastName`, and `email` of employees whose job title is `'Sales Rep'` and order them in descending order of `employeeNumber`.  
4. Write a query to retrieve all the columns and records from the `offices` table.  
5. Write a query to fetch the `productName` and `quantityInStock` from the `products` table. Sort the results in ascending order of `buyPrice` and limit the output to **5 records**.  

---

## 📂 Files in this Repository
- **answers.sql** → Contains all the SQL queries for the assignment, with comments.  

---

## 🛠️ How to Run the Queries
1. Open **MySQL Workbench** (or any SQL client connected to MySQL).  
2. Make sure you are using the correct database:
   ```sql
   USE salesDB;
   ```
3. Open the file **answers.sql** in Workbench.  
4. Run the queries one by one (or all at once).  
5. You should see results for each query in the output panel.  

---

## ✍️ Notes
- The queries are structured with comments for clarity.  
- Make sure your `salesDB` database contains the required tables (`payments`, `orders`, `employees`, `offices`, `products`).  
- If the tables are empty, insert sample data before running the queries.  
